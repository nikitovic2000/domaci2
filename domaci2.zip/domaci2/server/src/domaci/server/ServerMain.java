package domaci.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ServerMain {
    public static final int PORT = 9191;
    public static List<ServerThread> threads = new CopyOnWriteArrayList<ServerThread>();
    public static List<String> korisnici = new CopyOnWriteArrayList<>();
    public static final String  lock = "LOCK";
    public static List<String> istorijaPoruka = new CopyOnWriteArrayList<>();





    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        istorijaPoruka.stream().limit(100);
        try {
            serverSocket = new ServerSocket(PORT);

            while (true) {
                System.out.println("Server ceka konekciju");
                Socket socket = serverSocket.accept();
                ServerThread serverThread = new ServerThread(socket);
                Thread thread = new Thread(serverThread);
                threads.add(serverThread);
                thread.start();
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}