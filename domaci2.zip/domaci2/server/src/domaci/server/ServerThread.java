package domaci.server;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static domaci.server.ServerMain.*;

public class ServerThread implements Runnable{


    Socket socket;
    BufferedReader in;
    PrintWriter out;


    public ServerThread(Socket socket){
        this.socket = socket;
        try {
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void run() {

        try {
            out.println("Vase korisnicko ime:");
            String poruka;

            String username = null;


            while (username == null) {
                poruka = in.readLine();
                // System.out.println(poruka);

                synchronized (lock) {

                    if (!korisnici.contains(poruka)) {
                        //    System.out.println("If petlja");
                        username = poruka;
                          //System.out.println(username);
                        out.println(username);
                        korisnici.add(username);
                        System.out.println(korisnici);
                        break;
                    } else {
                        out.println("Korisnicko ime je zauteo, pokusajte sa nekim drugim.");
                        //System.out.println("else petlja");
                    }
                }
            }
            out.println("Dobrodosao " + username +"!\n" + istorijaPoruka);

            if(username != null) {
                for (ServerThread serverThread : threads) {
                    serverThread.out.println(username + " je pristupio cetu.");
                }
            }

            System.out.println(istorijaPoruka);

            while (true){
                poruka = in.readLine();
                istorijaPoruka.add(poruka);
                for(ServerThread serverThread : threads) {

                    serverThread.out.println(poruka);
                }



            }







        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (out != null) {
                out.close();
            }
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
