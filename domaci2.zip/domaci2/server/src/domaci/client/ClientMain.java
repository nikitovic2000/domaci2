package domaci.client;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class ClientMain {

    public static final int PORT = 9191;
    public static final String lock = "LOCK";

    private static String username;



    public ClientMain() throws IOException {

        this.username = null;

    }


    public static void main(String[] args) {


        try{

            //istorijaPoruka.stream().limit(100);
            Socket socket = new Socket("127.0.0.1", PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

            Scanner scanner = new Scanner(System.in);


            String poruka;

            //poruka = in.readLine();

            poruka = in.readLine();
            System.out.println(poruka);


            while(username == null){
                synchronized (lock) {
                    out.println(scanner.nextLine());
                    poruka = in.readLine();
                    if (poruka.equals("Korisnicko ime je zauteo, pokusajte sa nekim drugim.")) {
                        System.out.println(poruka);
                       // poruka = scanner.nextLine();
                                  // System.out.println("if petlja");
                        //out.println(poruka);
                    } else {
                        username = poruka;
                                 //System.out.println("Else petlja");
                        break;
                    }
                }
            }

                System.out.println(in.readLine());




            PrintWriter finalOut = out;

            Thread sendMessage = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {

                        String msg = scanner.nextLine();

                        //ServerMain.istorijaPoruka.add(LocalDate.now() + " " + LocalTime.now() + ", " + username + ": " + proveraCenzure(msg));
                        //System.out.println("Usao sam ovde - send");
                        finalOut.println(LocalDate.now() + " " + LocalTime.now() + ", " + username + ": " + proveraCenzure(msg));

                    }
                }
            });


            BufferedReader finalIn = in;
            Thread readMessage = new Thread(new Runnable() {

                @Override
                public void run() {

                    while (true) {
                        try {

                            String msg = finalIn.readLine();
                            //System.out.println("Usao sam ovde - read");

                            System.out.println(msg);
                        } catch (IOException e) {

                            e.printStackTrace();
                        }
                    }
                }
            });

            sendMessage.start();
            readMessage.start();


        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    public static String proveraCenzure(String poruka){
        // Rat, Covid, Korona
        if(poruka.equalsIgnoreCase("rat") || poruka.contains("rat"))
            return "r*t";
        if(poruka.equalsIgnoreCase("covid") || poruka.contains("covid"))
            return "c***d";
        if(poruka.equalsIgnoreCase("korona") || poruka.contains("korona"))
            return "k****a";
        return poruka;
    }



}
